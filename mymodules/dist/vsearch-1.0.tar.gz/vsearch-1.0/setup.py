from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    description='The head first Python search tools',
    py_modules=['vsearch'],
)
