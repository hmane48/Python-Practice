def search4vowels(word,abc):
    """This program searches for the vowels"""
    return set(abc).intersection(set(word))
